import { NgIf } from '@angular/common';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-inscription',
  standalone: true,
  imports: [NgIf, FormsModule],
  templateUrl: './inscription.component.html',
  styleUrl: './inscription.component.css'
})
export class InscriptionComponent implements OnInit {

  email:string|undefined;
  password:string|undefined;
  msgerreur:string="";

  ngOnInit(){}

  constructor(public http:HttpClient){}

  inscription()
  {
    if(this.email==undefined && this.password ==undefined)
      {
        this.msgerreur =" Saisir email and password";
      }
      else
      {
        this.http.post("http://localhost/miniprojet/inscription.php",{"email":this.email, "password":this.password}, {observe:'response',responseType: 'json'}).subscribe(
          {
              next : (response)=>{
                if(response.status ==201)
                  alert("Ajout client effectué avec succès");
                else
                  {
                   const body:any=  response.body;
                    alert("Echec : "+ body['msg']);}
              },
              error: (error)=> this.msgerreur = error
          }

       
        );
      }
  }

}
